Laura Douglas
CS504
Calculator (using sockets)

How to run:
1-open Calculator.java.
2-open Server.java.
3-run server.java and calculator.java, one after the other to establish server connection
4-you can now begin input expressions you would like to be evaluated, carefully following
    input guides provided.
5-when asked if you would like to print, say 'print' if you would like to see all your
    expression input and their respective result. if you don't want to print yet, skip this
    by hitting the 'enter' key
6-when asked if you would like to quit, say 'quit' to end the program. you are able to view
    all your inputs and their result in text file (yourcalculations.txt), even after you quit.
    alternatively, if you want to carry on calculating, simply skip by hitting the 'enter'
    key.